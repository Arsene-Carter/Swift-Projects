//
//  FinaleApp.swift
//  Finale
//
//  Created by    CHIKA Ali on 24/03/2021.
//

import SwiftUI

@main
struct FinaleApp: App {
    var body: some Scene {
        WindowGroup {
            AcceuilApp()
        }
    }
}
