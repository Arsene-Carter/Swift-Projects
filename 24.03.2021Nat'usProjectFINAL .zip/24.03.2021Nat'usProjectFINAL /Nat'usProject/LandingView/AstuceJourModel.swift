//
//  AstuceJourModel.swift
//  NatUs
//
//  Created by Marina FERNANDEZ on 09/03/2021.
//

import Foundation

struct AstuceJourModel {

    let infos: String
    let tip: String
    //let name: String
    //let id: Int
}

let elec1AstuceJour = AstuceJourModel(infos: "Un ascenseur consomme entre 5 et 8% de l’énergie électrique d’un bâtiment.", tip: "Prendre l’escalier plutôt que l’ascenseur va réduire la consommation électrique, la pollution sonore et vous aurez de belles fesses.")
let ville1AstuceJour = AstuceJourModel(infos: "En France 9 personnes sur 10 vivent en ville!", tip: "C’est pourquoi il est indispensable que les citadins participent à l’effort de préserver notre biodiversité.")
let bee1AstuceJour = AstuceJourModel(infos: "Les abeilles sont gravement menacées avec un taux d'extinction qui est de 100 à 1000 fois plus élevé que la normale", tip: "Une des raisons étant la destruction de leurs habitats, vous pouvez installer un hôtel à abeilles sur votre terrasse ou le jardin de l'immeuble.")
