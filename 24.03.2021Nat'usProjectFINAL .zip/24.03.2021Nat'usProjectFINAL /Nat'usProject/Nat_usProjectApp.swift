//
//  Nat_usProjectApp.swift
//  Nat'usProject
//
//  Created by CHRISTOPHE LEHOUSSINE on 2021-03-15.
//

import SwiftUI

@main
struct Nat_usProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
