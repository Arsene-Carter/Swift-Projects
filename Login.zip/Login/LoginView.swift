//
//  LoginView.swift
//  Filtres
//
//  Created by ouazzi mounir on 16/03/2021.
//

import SwiftUI

struct LoginView: View {
    @State var email: String = ""
    @State var password: String = ""
    let lightGreyColor = Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0, opacity: 1.0)
    @State private var mdpoublie = false
    @State private var showRegister = false
    
    var body: some View {
        NavigationView{
            VStack{
                Image("logoEcoTrip")
                    .resizable()
                    .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                    .frame(width: 100, height: 100)
                    .padding(.bottom)

                TextField("E-mail", text: $email)
                    .padding()
                    .background(lightGreyColor)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .padding(5)
                
                SecureField("Mot de passe", text: $password)
                    .padding()
                    .background(lightGreyColor)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .padding(5)
                Button(action: {
                    self.mdpoublie = true
                }, label: {
                    Text("Mot de passe oublié ?")
                        .bold()
                        .font(.system(size: 15))
                        .foregroundColor(Color.ButtonColor)
                        .padding(.bottom)
                        .offset(x: 100)
                })
                Button(action: {
                }, label: {
                    Text("Se connecter")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 350, height: 45)
                        .background(Color.ButtonColor)
                        .cornerRadius(10)
                        .padding(5)
                }).disabled(email.isEmpty || password.isEmpty)
                Spacer()
                Button(action: {
                    self.showRegister = true
                }, label: {
                    Text("Nouveau sur Eco-Trip ? Inscrivez-vous.")
                        .font(.system(size: 15))
                        .foregroundColor(Color.ButtonColor)
                        .padding(.bottom)
                })
                NavigationLink(destination: OublieView(), isActive: $mdpoublie) {}
                NavigationLink(destination: RegisterView(), isActive: $showRegister) {}
            }
            .padding()
        }.navigationBarHidden(true)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
