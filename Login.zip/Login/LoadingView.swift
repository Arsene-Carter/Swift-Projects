//
//  LoadingView.swift
//  Filtres
//
//  Created by ouazzi mounir on 18/03/2021.
//

import SwiftUI

struct LoadingView: View {
    @State var show = false
    var body: some View {
        NavigationView{
            VStack {
            Image("logoEcoTrip")
                .resizable()
                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                .frame(width: 150, height: 150, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            NavigationLink(destination: WelcomeView(), isActive: $show, label: {})
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        show = true
                    }
        }
            }
    }
    }
}
    struct LoadingView_Previews: PreviewProvider {
        static var previews: some View {
            LoadingView()
        }
    }
