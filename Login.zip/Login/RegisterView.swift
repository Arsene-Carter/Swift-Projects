//
//  RegisterView.swift
//  Filtres
//
//  Created by ouazzi mounir on 16/03/2021.
//

import SwiftUI

struct RegisterView: View {
    @State var email: String = ""
    @State var password: String = ""
    @State private var showPassword = false

    let lightGreyColor = Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0, opacity: 1.0)
    
    @State private var create = false
    @State private var already = false

    var body: some View {
        NavigationView{
            VStack{
                Image("logoEcoTrip")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .padding(.bottom)

                HStack {
                    Image(systemName: "person.fill")
                        .foregroundColor(.secondary)
                    TextField("E-mail", text: self.$email)
                }
                .padding()
                .background(lightGreyColor)
                .foregroundColor(.black)
                .cornerRadius(10)
                .padding(5)
                
                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundColor(.secondary)
                    if showPassword {
                        TextField("Mot de passe", text: self.$password)
                    } else {
                        SecureField("Mot de passe", text: self.$password)
                    }
                    Button(action: { self.showPassword.toggle()}) {
                        
                        Image(systemName: self.showPassword ? "eye.slash" : "eye.fill")
                            .foregroundColor(.secondary)
                    }
                }.padding()
                .background(lightGreyColor)
                .foregroundColor(.black)
                .cornerRadius(10)
                .padding(5)
                
                Button(action: {
                    self.create = true
                }, label: {
                    Text("Créer le compte")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 350, height: 45)
                        .background(Color.ButtonColor)
                        .cornerRadius(10)
                        .padding(5)
                    
                }).disabled(email.isEmpty || password.isEmpty)
                Button(action: {
                    self.already = true
                }, label: {
                    Text("J'ai déjà un compte !")
                        .font(.system(size: 15))
                        .underline()
                        .foregroundColor(Color.ButtonColor)
                        .padding(.bottom)
                })
                
                NavigationLink(destination: ContentView(), isActive: $create) {}
                NavigationLink(destination: LoginView(), isActive: $already) {}
            }
        }.navigationBarHidden(true)
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}

