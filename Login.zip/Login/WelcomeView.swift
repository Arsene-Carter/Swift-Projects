//
//  WelcomeView.swift
//  Filtres
//
//  Created by ouazzi mounir on 16/03/2021.
//

import SwiftUI

struct WelcomeView: View {
    @State private var showLogin = false
    @State private var showRegister = false
    @State private var after = false
    
    var body: some View {
        
        NavigationView{
            VStack{
                Image("logoEcoTrip")
                    .resizable()
                    .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                    .frame(width: 150, height: 150)
                    .padding(20)
                Text("Eco-Trip")
                    .font(.largeTitle)
                    .foregroundColor(Color.ButtonColor)
                    .bold()
                Spacer()
                HStack{
                Button(action: {
                    self.showLogin = true
                }, label: {
                    Text("Se connecter")
                        .font(.headline)
                        .foregroundColor(.ButtonColor)
                        .padding()
                        .frame(width: 170, height: 60)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.ButtonColor, lineWidth: 3)
                        )
                })
                Button(action: {
                    self.showRegister = true
                }, label: {
                    Text("Créer un compte")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 170, height: 60)
                        .background(Color.ButtonColor)
                        .cornerRadius(10)
                })
                }
                .padding()
                Button(action: {
                    self.after = true
                }, label: {
                    Text("Plus tard")
                        .underline()
                        .foregroundColor(Color.ButtonColor)
                        .padding(.bottom)
                })
                NavigationLink(destination: LoginView(), isActive: $showLogin) {}
                NavigationLink(destination: RegisterView(), isActive: $showRegister) {}
                NavigationLink(destination: ContentView(), isActive: $after) {}
            }
        }.navigationBarHidden(true)
    }
}
struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
