//
//  OublieView.swift
//  Filtres
//
//  Created by ouazzi mounir on 16/03/2021.
//

import SwiftUI

struct OublieView: View {
    
    @State var email: String = ""
    @State var retour = false
    let lightGreyColor = Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0, opacity: 1.0)
    
    var body: some View {
        NavigationView{
            VStack{
                Image(systemName: "lock.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .foregroundColor(Color.ButtonColor)
                
                Text("Des difficultés de connexion ?")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding()
                    .foregroundColor(Color.ButtonColor)

                Text("Entrez votre e-mail et nous vous enverrons un lien pour récupérer votre compte.")
                    .font(.system(size: 15))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding()
                TextField("E-mail", text: $email)
                    .padding()
                    .background(lightGreyColor)
                    .foregroundColor(Color.ButtonColor)
                    .cornerRadius(10)
                    .padding(5)
                
                Button(action: {
                }, label: {
                    Text("Suivant")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 350, height: 45)
                        .background(Color.ButtonColor)
                        .cornerRadius(10)
                        .padding(5)
                }).disabled(email.isEmpty)
                Spacer()
                Button(action: {
                    self.retour = true
                }, label: {
                    Text("Retour à la connexion")
                        .font(.system(size: 15))
                        .underline()
                        .foregroundColor(Color.ButtonColor)
                        .padding(.bottom)
                })
                NavigationLink(destination: LoginView(), isActive: $retour) {}
            }
            .padding()
        }.navigationBarHidden(true)
    }
}

struct OublieView_Previews: PreviewProvider {
    static var previews: some View {
        OublieView()
    }
}
