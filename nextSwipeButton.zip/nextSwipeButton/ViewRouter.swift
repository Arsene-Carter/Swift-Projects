//
//  ViewRouter.swift
//  nextSwipeButton
//
//  Created by Mahfod Addi on 23/03/2021.
//

import Foundation
import SwiftUI

class ViewRouter: ObservableObject {
    
   @Published var currentPage: Page = .page1
    
}
