//
//  ContentViewA.swift
//  nextSwipeButton
//
//  Created by Mahfod Addi on 23/03/2021.
//

import SwiftUI

struct ContentViewA: View {
    
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
        VStack {
            FishEat() // fonction qui appelle l'image voir ci-dessous
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .page2 // initialisation de l'action qui envoie vers la page 2 
                }
            }) {
                NextButtonContent() // Création du button voir ci-dessus
            }
        }
    }
}

struct ContentViewA_Previews: PreviewProvider {
    static var previews: some View {
        ContentViewA().environmentObject(ViewRouter())
    }
}



struct NextButtonContent : View {
    var body: some View {
        Text("Next")
            .foregroundColor(.white)
            .frame(width: 200, height: 50)
            .background(Color.blue)
            .cornerRadius(15)
            .padding(.top, 50)
    }
}

struct FishEat : View {
    var body: some View {
        Image("Fishing")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 300, height: 600)
            .cornerRadius(10)
            .clipped()
    }
}
