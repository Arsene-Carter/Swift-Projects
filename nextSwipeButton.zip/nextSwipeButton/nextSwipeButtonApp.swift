//
//  nextSwipeButtonApp.swift
//  nextSwipeButton
//
//  Created by Mahfod Addi on 23/03/2021.
//

import SwiftUI

@main
struct nextSwipeButtonApp: App {
    @StateObject var viewRouter = ViewRouter()
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(viewRouter)
        }
    }
}
