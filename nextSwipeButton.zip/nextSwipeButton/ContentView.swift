//
//  ContentView.swift
//  nextSwipeButton
//
//  Created by Mahfod Addi on 23/03/2021.
//

import SwiftUI

struct ContentView: View {
    
  //Initialisation de la variable pour accéder a tous les élements
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
//       Création de la condition avec enum si rajout de plusieurs elements il faut modifier le enum
        
        switch viewRouter.currentPage {
           case .page1:
               ContentViewA()
           case .page2:
               ContentViewB()
           }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
//        on rattache l'ensemble 
        
        ContentView().environmentObject(ViewRouter())
    }
}
