//
//  Helpers.swift
//  nextSwipeButton
//
//  Created by Mahfod Addi on 23/03/2021.
//

import Foundation

// Création de l'enum à ajouter ici si besoin de plus d'images
enum Page {
    case page1
    case page2
}
