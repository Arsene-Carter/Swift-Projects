//
//  ScreenAView.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import SwiftUI

struct ScreenAView: View {
    @State private var AddFav = false
    @EnvironmentObject var viewRouter: ViewRouter
    @State var showSheet = false
    
    var body: some View {
        VStack{
            
            LieuA(infos: mornantSeguin)
            HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 20){
                Button(action: {
                    withAnimation {
                        viewRouter.currentPage = .page2
                    }
                }) {
                    NextButtonContent()
                }
                Button(action: {
                    showSheet = true
                }) {
                    BookingButtonContent()
                }.sheet(isPresented: $showSheet) {
                    DescriptifView(lien: tableau[0])
                }
                Button(action: {
                    AddFav = true
                }) {
                    FavButtonContent()
                }.alert(isPresented:$AddFav) {
                    Alert(title: Text("Salut"), message: Text("Tu as ajouté ce lieu dans tes favoris."), dismissButton: .default(Text("Ok")){
                        viewRouter.currentPage = .page2
                    })
                }
            }
        }
    }
}
struct ScreenAView_Previews: PreviewProvider {
    static var previews: some View {
        ScreenAView().environmentObject(ViewRouter())
    }
}

//Bouton Heart
struct FavButtonContent : View {
    var body: some View {
        Image("Favoris")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 65, height: 65, alignment: .center)
            .foregroundColor(Color.black)
            .clipShape(Circle())
    }
}

//Bouton X
struct NextButtonContent : View {
    var body: some View {
        Image("Croix")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 65, height: 65, alignment: .center)
            .foregroundColor(Color.black)
            .clipShape(Circle())
    }
}

//Bouton Réserver
struct BookingButtonContent : View {
    var body: some View {
        Text("DÉTAILS")
            .font(.headline)
            .foregroundColor(.yellow)
            .padding()
            .frame(width: 180, height: 55)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.yellow, lineWidth: 3)
            )
    }
}

//Image + Texte du lieu
struct LieuA : View {
    let infos: ModelDescription
    var body: some View {
        ZStack{
            Image(infos.photo)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .opacity(0.3)
                .background(Color.black)
                .frame(width: 400, height: 750)
                .cornerRadius(30)
            VStack(){
                Spacer()
                VStack(alignment: .leading){
                    HStack{
                        Text(infos.titre)
                            .fontWeight(.bold)
                            .font(.system(size: 25))
                    }
                    Text(infos.ville)
                        .font(.title3)
                }
            }
            .padding()
            .foregroundColor(.white)
            .offset(x: -20, y: -50)
        }
    }
}
//struct SheetView: View {
//    @Binding var showSheetView: Bool
//    let infos: ModelDescription
//    var body: some View {
//        NavigationView {
//            Text(infos.titre)
//            .navigationBarTitle(Text("Détails"), displayMode: .inline)
//                .navigationBarItems(trailing: Button(action: {
//                    print("Dismissing sheet view...")
//                    self.showSheetView = false
//                }) {
//                    Text("Ok").bold()
//                })
//        }
//    }
//}
