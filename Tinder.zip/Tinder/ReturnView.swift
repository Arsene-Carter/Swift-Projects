//
//  Reto.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import SwiftUI

struct ReturnView: View {
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var Accueil = false
    var body: some View {
        VStack{
        Spacer()
        Text("Fin des 5 propositions !")
            .font(.largeTitle)
            Button(action: {
                withAnimation {
                    viewRouter.currentPage = .page1 // initialisation de l'action qui envoie vers la page 2
                }
            }) {
                ReturnButtonContent() // Création du button voir ci-dessus
            }
            Spacer()
            Button(action: {
                self.Accueil = true
            }, label: {
                Text("Retourner à l'accueil")
                    .underline()
                    .foregroundColor(Color.ButtonColor)
                    .padding(.bottom)
            })
    }
    }
}

struct ReturnView_Previews: PreviewProvider {
    static var previews: some View {
        ReturnView().environmentObject(ViewRouter())
    }
}

struct ReturnButtonContent : View {
    var body: some View {
        Image(systemName: "repeat.circle")
            .resizable()
            .frame(width: 50, height: 50, alignment: .center)
            .aspectRatio(contentMode: .fill)
            .padding()
            .foregroundColor(Color.ButtonColor)
            .clipShape(Circle())
    }
}
