//
//  DescriptifView.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import SwiftUI

struct DescriptifView: View {
    let lien: ModelDescription
//    @State private var favoriButton = false
    @State private var show = false
    @State private var isPresented = false
  
    var body: some View {
        
//       NavigationView{
            VStack {
                TopView(image: lien.photo)
                    .frame(width: 600, height: 00, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                HStack(){
                
                    Spacer()
                    
                    Button(action: {
                    
                    show = true
                    
                    
                }, label: {
//                    Image("coeur")
//                        .resizable()
//                        .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
//                        .frame(height: 50)
//                        .clipped()
//                        .overlay(Rectangle().opacity(0.1))
//                        .ignoresSafeArea()
//
                    Image("coeur")
                        .resizable()
                        .frame (width: 50, height: 50)
                        .background(Circle().fill(Color.white))
                        .padding()
                }).frame(width: 70, height: 30, alignment: .leading)
              
                .alert(isPresented: $show) {
                                    Alert(title: Text("Favoris"), message: Text("Lieu ajouté à vos favoris"), dismissButton: .default(Text("Ok")))
                                }
            
                   }
               
                
                HStack{
                    Spacer()
                    
                    Text(lien.titre)
                        .font(.title2)
                        .bold()
                        .padding(.top, 50)
                    Spacer()
                }
               
                HStack(){

                  NavigationLink(
                    destination: mapMorantView(),
                    label: {
                        Image(lien.pinIcone)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                            .padding(.leading, 20)
                        
                        Text(lien.ville)

                        Spacer()
                    })
                    
    //                Image(lien.pinIcone)
    //                    .resizable()
    //                    .aspectRatio(contentMode: .fit)
    //                    .frame(width: 30, height: 30)
    //                    .padding(.leading, 20)
    //
    //                Text(lien.ville)
    //
    //                Spacer()
                }

                
                HStack {
                   
                    
                    NavigationLink(
                        destination: descriptifSeguinView(),
                        label: {
                            Image(systemName: lien.textIcone)
            //                    .font(.system(size: 20))
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 25, height: 25)
                                .padding(.leading, 20)
                                .foregroundColor(Color("colorVertBouton"))
                        })
                    
                    
                    
                    
                    
                    
                    
                    
//                    Image(systemName: lien.textIcone)
//    //                    .font(.system(size: 20))
//                        .resizable()
//                        .aspectRatio(contentMode: .fit)
//                        .frame(width: 25, height: 25)
//                        .padding(.leading, 20)
//                        .foregroundColor(Color("colorVertBouton"))
                    
                    
                    Text(lien.resume)
                        .fontWeight(.light)
                        .padding(.horizontal, 5)
                        .padding(.bottom, 20)
                        .frame(height: 115)
                    
                    Spacer()
                }
                
                HStack{
                    ForEach(lien.actIcone, id: \.self) {
                        Image($0)
                            .resizable()
                            .frame(width: 100, height: 100)
                    }
                }
                
                HStack {
                    ForEach(lien.textActivite, id: \.self) {
                        Text($0)
                            .frame(width: 110)
                    }
                }
                
                HStack{
                    ForEach(lien.localIcone, id: \.self) {
                        Image($0)
                            .resizable()
                            .frame(width: 100, height: 100)
                    }
                }
                
                HStack {
                    ForEach(lien.textLocal, id: \.self) {
                        Text($0)
                            .frame(width: 100)
                            .padding(.bottom)
                    }
                }
        
                HStack {
                    Button(action: {
                            
                            isPresented = true }
                           , label: {
                            
                            Text("Réserver")
                                
                                .foregroundColor(.white)
                                .padding(20)
                                .padding(.horizontal, 20)
                                .background(Color("colorVertBouton"))
                                .font(.title3)
                                .cornerRadius(15)
                            //                            .shadow(radius: 10)
                           }
                           
                    ).sheet(isPresented: $isPresented, content: {
                        Group {
                            
                            Button(action: {
                                self.isPresented.toggle()
                            }) {
                                
                                Text("X")
                                    .frame(width: 380, alignment: .trailing)
                            }
                        }
                    
                        ModalReserveView()
                        
                    })
                }
                //Spacer()
            }
        }
    }



struct DescriptifView_Previews: PreviewProvider {
    static var previews: some View {
        DescriptifView(lien: mornantSeguin)
        DescriptifView(lien: lavandeVaucluse)
        DescriptifView(lien: foretSherwood)
        DescriptifView(lien: sainteVictoire)
        DescriptifView(lien: camping)


    }
}


struct TopView: View {
    let image: String
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            
//            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
//                Image(image)
//                    .resizable()
//                    .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
//                    .frame(height: 200)
//                    .clipped()
//                    .overlay(Rectangle().opacity(0.1))
//                    .ignoresSafeArea()
//
//                Image("coeur")
//                    .resizable()
//                    .frame (width: 50, height: 50)
//                    .background(Circle().fill(Color.white))
//                    .padding()
//            })
            
            
            Image(image)
                .resizable()
                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                .frame(height: 200)
                .clipped()
                .overlay(Rectangle().opacity(0.1))
                .ignoresSafeArea()

//            Image("coeur")
//                .resizable()
//                .frame (width: 50, height: 50)
//                .background(Circle().fill(Color.white))
//                .padding()
        }
    }
}
