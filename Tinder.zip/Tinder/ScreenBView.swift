//
//  ScreenAView.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import SwiftUI

struct ScreenBView: View {
    @EnvironmentObject var viewRouter: ViewRouter
    @State private var AddFav = false
    @State private var showSheet = false
    var body: some View {
        VStack{
            
            LieuB(infos: sainteVictoire)
            HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 20){
                Button(action: {
                    withAnimation {
                        viewRouter.currentPage = .page3
                    }
                }) {
                    NextButtonContent()
                }
                Button(action: {
                    showSheet = true
                }) {
                    BookingButtonContent()
                }.sheet(isPresented: $showSheet) {
                    DescriptifView(lien: tableau[3])
                }
                Button(action: {
                    AddFav = true
                }) {
                    FavButtonContent()
                }.alert(isPresented:$AddFav) {
                    Alert(title: Text("Salut"), message: Text("Tu as ajouté ce lieu dans tes favoris."), dismissButton: .default(Text("Ok")){
                        viewRouter.currentPage = .page3
                    })
                }
            }
        }
    }
}
struct ScreenBView_Previews: PreviewProvider {
    static var previews: some View {
        ScreenBView().environmentObject(ViewRouter())
    }
}
//Image + Texte du lieu
struct LieuB : View {
    let infos: ModelDescription
    var body: some View {
        ZStack{
            Image(infos.photo)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .opacity(0.3)
                .background(Color.black)
                .frame(width: 400, height: 750)
                .cornerRadius(30)
            VStack(){
                Spacer()
                VStack(alignment: .leading){
                    HStack{
                        Text(infos.titre)
                            .fontWeight(.bold)
                            .font(.system(size: 25))
                    }
                    Text(infos.ville)
                        .font(.title3)
                }
            }
            .padding()
            .foregroundColor(.white)
            .offset(x: -20, y: -50)
        }
    }
}
