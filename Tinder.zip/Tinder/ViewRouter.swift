//
//  ViewRouter.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import Foundation
import SwiftUI

class ViewRouter: ObservableObject {
    
   @Published var currentPage: Page = .page1
    
}
