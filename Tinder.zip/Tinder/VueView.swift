//
//  VueVIew.swift
//  Filtres
//
//  Created by ouazzi mounir on 24/03/2021.
//

import SwiftUI

struct VueVIew: View {
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
        switch viewRouter.currentPage {
        case .page1:
            ScreenAView()
        case .page2:
            ScreenBView()
        case .page3:
            ScreenCView()
        case .page4:
            ScreenDView()
        case .page5:
            ScreenEView()
        case .page6:
            ReturnView()
        }
    }
}

struct VueVIew_Previews: PreviewProvider {
    static var previews: some View {
        VueVIew().environmentObject(ViewRouter())
    }
}
